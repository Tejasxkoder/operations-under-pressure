import { defineConfig } from 'vitest/config';

const url = process.env.TEST_DATABASE_URL ?? 'postgres://ops:ops@localhost:5432/ops_test';

export default defineConfig({
  test: {
    globalSetup: ['./tests/globalSetup.ts'],
    fileParallelism: false,
    testTimeout: 20000,
    env: { DATABASE_URL: url, JWT_SECRET: 'test-secret', RUN_WORKER: 'false' },
  },
});
