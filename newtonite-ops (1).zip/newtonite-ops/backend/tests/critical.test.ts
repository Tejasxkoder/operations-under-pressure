import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { pool } from '../src/db';
import { defaultHandlers, enqueue, processJobs } from '../src/jobs';
import { app, as, createItem, resetWorld, type World } from './helpers';

let w: World;
beforeEach(async () => { w = await resetWorld(); });
afterAll(async () => { await pool.end(); });

describe('login', () => {
  it('returns a token for valid credentials and rejects bad ones', async () => {
    const ok = await request(app).post('/api/auth/login').send({ email: 'leadA@t.test', password: 'Passw0rd!' });
    expect(ok.status).toBe(200);
    expect(ok.body.token).toBeTruthy();
    const bad = await request(app).post('/api/auth/login').send({ email: 'leadA@t.test', password: 'nope' });
    expect(bad.status).toBe(401);
    expect((await request(app).get('/api/items')).status).toBe(401);
  });
});

describe('concurrent claim', () => {
  it('only one of many parallel claims wins; the rest get 409', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    const claimers = [w.tokens.memberA1, w.tokens.memberA2, w.tokens.leadA, w.tokens.memberA1, w.tokens.memberA2, w.tokens.leadA];
    const results = await Promise.all(claimers.map((t) => as(t).post(`/api/items/${item.id}/claim`)));
    const statuses = results.map((r) => r.status);
    expect(statuses.filter((s) => s === 200)).toHaveLength(1);
    expect(statuses.filter((s) => s === 409)).toHaveLength(claimers.length - 1);

    const events = await pool.query(`SELECT count(*)::int AS n FROM activity_events WHERE item_id = $1 AND kind = 'assignee_changed'`, [item.id]);
    expect(events.rows[0].n).toBe(1); // history agrees with the item
    const row = await pool.query('SELECT assignee_id, status, version FROM work_items WHERE id = $1', [item.id]);
    expect(row.rows[0].status).toBe('in_progress');
    expect(row.rows[0].version).toBe(2);
  });
});

describe('stale update (optimistic locking)', () => {
  it('rejects an old version with 409 + latest item and leaves data unchanged', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    const first = await as(w.tokens.memberA1).patch(`/api/items/${item.id}`, { version: 1, title: 'First edit' });
    expect(first.status).toBe(200);
    expect(first.body.item.version).toBe(2);

    const stale = await as(w.tokens.memberA2).patch(`/api/items/${item.id}`, { version: 1, title: 'Stale edit' });
    expect(stale.status).toBe(409);
    expect(stale.body.error).toBe('version_conflict');
    expect(stale.body.latest.title).toBe('First edit');

    const row = await pool.query('SELECT title, version FROM work_items WHERE id = $1', [item.id]);
    expect(row.rows[0]).toEqual({ title: 'First edit', version: 2 });
  });

  it('records priority changes in the activity log in the same transaction', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    await as(w.tokens.memberA1).patch(`/api/items/${item.id}`, { version: 1, priority: 'urgent' });
    const res = await as(w.tokens.memberA1).get(`/api/items/${item.id}/activity`);
    const kinds = res.body.events.map((e: any) => e.kind);
    expect(kinds).toEqual(['created', 'priority_changed']);
    expect(res.body.events[1].data).toEqual({ from: 'high', to: 'urgent' });
  });
});

describe('idempotency', () => {
  it('the same Idempotency-Key creates exactly one item and replays the response', async () => {
    const body = { title: 'Double click', teamId: w.teamA };
    const key = { 'Idempotency-Key': 'key-123' };
    const a = await as(w.tokens.memberA1).post('/api/items', body, key);
    const b = await as(w.tokens.memberA1).post('/api/items', body, key);
    expect(a.status).toBe(201);
    expect(b.status).toBe(201);
    expect(b.body.item.id).toBe(a.body.item.id);
    expect(b.headers['idempotent-replay']).toBe('true');
    expect((await pool.query('SELECT count(*)::int AS n FROM work_items')).rows[0].n).toBe(1);
  });

  it('parallel duplicates with the same key still create one item', async () => {
    const body = { title: 'Racing duplicates', teamId: w.teamA };
    const results = await Promise.all(
      Array.from({ length: 6 }, () => as(w.tokens.memberA1).post('/api/items', body, { 'Idempotency-Key': 'race-key' })),
    );
    expect(new Set(results.map((r) => r.body.item.id)).size).toBe(1);
    expect(results.every((r) => r.status === 201)).toBe(true);
    expect((await pool.query('SELECT count(*)::int AS n FROM work_items')).rows[0].n).toBe(1);
  });

  it('rejects reusing a key for a different request', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    await as(w.tokens.memberA1).post('/api/items', { title: 'x', teamId: w.teamA }, { 'Idempotency-Key': 'shared' });
    const reuse = await as(w.tokens.memberA1).post(`/api/items/${item.id}/claim`, {}, { 'Idempotency-Key': 'shared' });
    expect(reuse.status).toBe(422);
  });
});

describe('workflow rules', () => {
  it('rejects invalid jumps (open -> closed)', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    const res = await as(w.tokens.leadA).post(`/api/items/${item.id}/transition`, { to: 'closed' });
    expect(res.status).toBe(422);
    expect(res.body.error).toBe('invalid_transition');
    expect((await pool.query('SELECT status FROM work_items WHERE id = $1', [item.id])).rows[0].status).toBe('open');
  });

  it('only a Lead of the team can approve', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    await as(w.tokens.memberA1).post(`/api/items/${item.id}/transition`, { to: 'in_progress' });
    await as(w.tokens.memberA1).post(`/api/items/${item.id}/transition`, { to: 'awaiting_approval' });

    const byMember = await as(w.tokens.memberA2).post(`/api/items/${item.id}/transition`, { to: 'resolved' });
    expect(byMember.status).toBe(403);
    const byOutsider = await as(w.tokens.memberB).post(`/api/items/${item.id}/transition`, { to: 'resolved' });
    expect(byOutsider.status).toBe(403);
    const byLead = await as(w.tokens.leadA).post(`/api/items/${item.id}/transition`, { to: 'resolved' });
    expect(byLead.status).toBe(200);
    expect(byLead.body.item.status).toBe('resolved');
  });
});

describe('resource-level authorization', () => {
  it('a user from another team cannot read or write the item, and does not see it in lists', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    const b = as(w.tokens.memberB);
    expect((await b.get(`/api/items/${item.id}`)).status).toBe(403);
    expect((await b.get(`/api/items/${item.id}/activity`)).status).toBe(403);
    expect((await b.patch(`/api/items/${item.id}`, { version: 1, title: 'hack' })).status).toBe(403);
    expect((await b.post(`/api/items/${item.id}/claim`)).status).toBe(403);
    expect((await b.post(`/api/items/${item.id}/comments`, { body: 'hi' })).status).toBe(403);
    expect((await b.post('/api/items', { title: 'x', teamId: w.teamA })).status).toBe(403);
    const list = await b.get('/api/items');
    expect(list.body.items).toHaveLength(0);
  });

  it('a viewer can read but not write; only a Lead can reassign', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    expect((await as(w.tokens.viewerA).get(`/api/items/${item.id}`)).status).toBe(200);
    expect((await as(w.tokens.viewerA).post(`/api/items/${item.id}/claim`)).status).toBe(403);
    expect((await as(w.tokens.viewerA).post(`/api/items/${item.id}/comments`, { body: 'x' })).status).toBe(403);

    const memberAssign = await as(w.tokens.memberA1).patch(`/api/items/${item.id}`, { version: 1, assigneeId: w.ids.memberA2 });
    expect(memberAssign.status).toBe(403);
    const leadAssign = await as(w.tokens.leadA).patch(`/api/items/${item.id}`, { version: 1, assigneeId: w.ids.memberA2 });
    expect(leadAssign.status).toBe(200);
    expect(leadAssign.body.item.assigneeId).toBe(w.ids.memberA2);
  });
});

describe('list: server-side filtering and cursor pagination', () => {
  it('paginates without duplicates and applies dashboard views', async () => {
    for (let i = 0; i < 25; i++) {
      await createItem(w.tokens.memberA1, w.teamA, { title: `Item ${i}`, priority: i % 5 === 0 ? 'urgent' : 'low' });
    }
    const p1 = await as(w.tokens.memberA1).get('/api/items?limit=10');
    expect(p1.body.items).toHaveLength(10);
    expect(p1.body.nextCursor).toBeTruthy();
    const p2 = await as(w.tokens.memberA1).get(`/api/items?limit=10&cursor=${p1.body.nextCursor}`);
    const p3 = await as(w.tokens.memberA1).get(`/api/items?limit=10&cursor=${p2.body.nextCursor}`);
    const all = [...p1.body.items, ...p2.body.items, ...p3.body.items].map((i: any) => i.id);
    expect(all).toHaveLength(25);
    expect(new Set(all).size).toBe(25);
    expect(p3.body.nextCursor).toBeNull();

    const urgent = await as(w.tokens.memberA1).get('/api/items?view=unassigned_urgent');
    expect(urgent.body.items).toHaveLength(5);
    const search = await as(w.tokens.memberA1).get('/api/items?q=item');
    expect(search.body.items).toHaveLength(25);
  });

  it('"awaiting my approval" only shows items in teams where I am a Lead', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    await as(w.tokens.memberA1).post(`/api/items/${item.id}/transition`, { to: 'in_progress' });
    await as(w.tokens.memberA1).post(`/api/items/${item.id}/transition`, { to: 'awaiting_approval' });
    expect((await as(w.tokens.leadA).get('/api/items?view=awaiting_my_approval')).body.items).toHaveLength(1);
    expect((await as(w.tokens.memberA2).get('/api/items?view=awaiting_my_approval')).body.items).toHaveLength(0);
  });
});

describe('reliable async work (transactional outbox)', () => {
  it('writes a job in the same transaction as the assignment; processing twice yields one notification', async () => {
    const item = await createItem(w.tokens.leadA, w.teamA, { assigneeId: w.ids.memberA1 });
    const jobs = await pool.query(`SELECT * FROM jobs WHERE type = 'notify_assignee'`);
    expect(jobs.rowCount).toBe(1);

    const stats = await processJobs();
    expect(stats.done).toBe(1);
    // simulate "worker crashed after the handler, before marking done" => handler runs again
    await defaultHandlers.notify_assignee(pool, jobs.rows[0].payload, jobs.rows[0]);
    const n = await pool.query('SELECT * FROM notifications WHERE item_id = $1', [item.id]);
    expect(n.rowCount).toBe(1);
    expect(n.rows[0].user_id).toBe(w.ids.memberA1);
  });

  it('a failing job is retried with backoff, then marked failed after max attempts', async () => {
    await enqueue(pool, 'boom', { x: 1 });
    await pool.query('UPDATE jobs SET max_attempts = 2');
    const handlers = { boom: async () => { throw new Error('downstream down'); } };

    expect((await processJobs(handlers)).retried).toBe(1);
    let job = (await pool.query('SELECT * FROM jobs')).rows[0];
    expect(job.status).toBe('pending');
    expect(job.attempts).toBe(1);
    expect(new Date(job.run_at).getTime()).toBeGreaterThan(Date.now()); // backoff scheduled

    await pool.query('UPDATE jobs SET run_at = now()');
    expect((await processJobs(handlers)).failed).toBe(1);
    job = (await pool.query('SELECT * FROM jobs')).rows[0];
    expect(job.status).toBe('failed');
    expect(job.last_error).toContain('downstream down');
  });
});

describe('activity log is append-only', () => {
  it('cannot be updated or deleted', async () => {
    const item = await createItem(w.tokens.memberA1, w.teamA);
    await expect(pool.query(`UPDATE activity_events SET kind = 'x' WHERE item_id = $1`, [item.id])).rejects.toThrow(/append-only/);
    await expect(pool.query(`DELETE FROM activity_events WHERE item_id = $1`, [item.id])).rejects.toThrow(/append-only/);
  });
});
