import fs from 'node:fs';
import pg from 'pg';

// Creates the ops_test database if needed and applies the schema.
export default async function setup() {
  const testUrl = process.env.TEST_DATABASE_URL ?? 'postgres://ops:ops@localhost:5432/ops_test';
  const dbName = new URL(testUrl).pathname.slice(1);
  const adminUrl = testUrl.replace(/\/[^/]*$/, '/postgres');

  const admin = new pg.Client({ connectionString: adminUrl });
  try {
    await admin.connect();
  } catch (e: any) {
    throw new Error(`Cannot reach Postgres (${e.message}). Start it with: docker compose up -d db`);
  }
  const exists = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [dbName]);
  if (exists.rowCount === 0) await admin.query(`CREATE DATABASE "${dbName}"`);
  await admin.end();

  const client = new pg.Client({ connectionString: testUrl });
  await client.connect();
  await client.query(fs.readFileSync(new URL('../src/schema.sql', import.meta.url), 'utf8'));
  await client.end();
}
