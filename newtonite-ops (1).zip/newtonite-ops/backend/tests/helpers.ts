import bcrypt from 'bcryptjs';
import request from 'supertest';
import { createApp } from '../src/app';
import { signToken } from '../src/auth';
import { pool } from '../src/db';

export const app = createApp();
const hash = bcrypt.hashSync('Passw0rd!', 4);

export interface World {
  teamA: string; teamB: string;
  tokens: Record<'leadA' | 'memberA1' | 'memberA2' | 'viewerA' | 'memberB', string>;
  ids: Record<'leadA' | 'memberA1' | 'memberA2' | 'viewerA' | 'memberB', string>;
}

/** Wipes the test DB and creates: team A (lead, 2 members, viewer) and team B (1 member). */
export async function resetWorld(): Promise<World> {
  await pool.query('TRUNCATE users, teams, memberships, work_items, activity_events, idempotency_keys, jobs, notifications RESTART IDENTITY CASCADE');
  const team = async (name: string) => (await pool.query('INSERT INTO teams (name) VALUES ($1) RETURNING id', [name])).rows[0].id as string;
  const teamA = await team('Team A');
  const teamB = await team('Team B');
  const ids: any = {}; const tokens: any = {};
  const user = async (key: string, team: string, role: string) => {
    const r = await pool.query('INSERT INTO users (email, name, password_hash) VALUES ($1,$2,$3) RETURNING id', [`${key}@t.test`, key, hash]);
    ids[key] = r.rows[0].id; tokens[key] = signToken(ids[key]);
    await pool.query('INSERT INTO memberships (user_id, team_id, role) VALUES ($1,$2,$3)', [ids[key], team, role]);
  };
  await user('leadA', teamA, 'lead');
  await user('memberA1', teamA, 'member');
  await user('memberA2', teamA, 'member');
  await user('viewerA', teamA, 'viewer');
  await user('memberB', teamB, 'member');
  return { teamA, teamB, tokens, ids };
}

export const as = (token: string) => ({
  get: (url: string) => request(app).get(url).set('Authorization', `Bearer ${token}`),
  post: (url: string, body: object = {}, headers: Record<string, string> = {}) =>
    request(app).post(url).set('Authorization', `Bearer ${token}`).set(headers).send(body),
  patch: (url: string, body: object = {}) =>
    request(app).patch(url).set('Authorization', `Bearer ${token}`).send(body),
});

export async function createItem(token: string, teamId: string, extra: object = {}) {
  const res = await as(token).post('/api/items', { title: 'Payment stuck', teamId, priority: 'high', type: 'payment', ...extra });
  if (res.status !== 201) throw new Error('createItem failed: ' + JSON.stringify(res.body));
  return res.body.item as { id: string; version: number; status: string };
}
