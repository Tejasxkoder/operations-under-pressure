import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { pool } from './db';

export async function migrate() {
  const sql = fs.readFileSync(fileURLToPath(new URL('./schema.sql', import.meta.url)), 'utf8');
  await pool.query(sql);
}

if (process.argv[1] && process.argv[1].endsWith('migrate.ts')) {
  migrate()
    .then(() => console.log('Migrations applied'))
    .catch((e) => { console.error(e); process.exit(1); })
    .finally(() => pool.end());
}
