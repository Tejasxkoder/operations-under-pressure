import type { PoolClient } from 'pg';
import { withTx } from './db';
import { AppError } from './errors';

export interface Result { status: number; body: any; replayed?: boolean }

/**
 * Runs `fn` in one transaction. With an Idempotency-Key the key row is inserted in
 * that same transaction: a concurrent duplicate blocks on the unique index until the
 * first request commits, then replays the stored response. If the first request fails,
 * the key is rolled back with it, so a retry runs normally.
 */
export async function runIdempotent(
  userId: string,
  key: string | undefined,
  scope: string,
  fn: (c: PoolClient) => Promise<Result>,
): Promise<Result> {
  return withTx(async (c) => {
    if (!key) return fn(c);
    if (key.length > 200) throw new AppError(400, 'validation_error', 'Idempotency-Key too long');

    const ins = await c.query(
      `INSERT INTO idempotency_keys (user_id, key, scope) VALUES ($1, $2, $3)
       ON CONFLICT DO NOTHING RETURNING key`,
      [userId, key, scope],
    );
    if (ins.rowCount === 0) {
      const { rows } = await c.query(
        'SELECT scope, status_code, response FROM idempotency_keys WHERE user_id = $1 AND key = $2',
        [userId, key],
      );
      const row = rows[0];
      if (row.scope !== scope) {
        throw new AppError(422, 'idempotency_key_reuse', 'This Idempotency-Key was used for a different request');
      }
      return { status: row.status_code, body: row.response, replayed: true };
    }

    const result = await fn(c);
    await c.query(
      'UPDATE idempotency_keys SET status_code = $3, response = $4 WHERE user_id = $1 AND key = $2',
      [userId, key, result.status, JSON.stringify(result.body)],
    );
    return result;
  });
}
