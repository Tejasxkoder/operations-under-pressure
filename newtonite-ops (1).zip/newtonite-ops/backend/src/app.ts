import fs from 'node:fs';
import path from 'node:path';
import express, { type NextFunction, type Request, type Response } from 'express';
import { authenticate, login, me } from './auth';
import { config } from './config';
import { pool } from './db';
import { AppError } from './errors';
import { runIdempotent } from './idempotency';
import * as items from './items';

const wrap = (fn: (req: Request, res: Response) => Promise<unknown>) => (req: Request, res: Response, next: NextFunction) =>
  Promise.resolve(fn(req, res)).catch(next);

export function createApp() {
  const app = express();
  app.use(express.json({ limit: '100kb' }));

  app.get('/api/health', wrap(async (_req, res) => {
    await pool.query('SELECT 1');
    res.json({ ok: true });
  }));

  app.post('/api/auth/login', wrap(async (req, res) => {
    res.json(await login(req.body?.email, req.body?.password));
  }));

  app.use('/api', authenticate);

  app.get('/api/me', wrap(async (req, res) => {
    const u = me(req);
    res.json({ user: { id: u.id, name: u.name, email: u.email }, memberships: u.memberships });
  }));

  app.get('/api/users', wrap(async (req, res) => res.json({ users: await items.listTeamUsers(me(req)) })));

  app.get('/api/items', wrap(async (req, res) => res.json(await items.listItems(me(req), req.query))));

  // Mutations: one transaction each; Idempotency-Key header makes retries / double-clicks safe.
  const mutate = (scope: string, fn: (c: any, user: any, req: Request) => Promise<any>) =>
    wrap(async (req, res) => {
      const user = me(req);
      const result = await runIdempotent(user.id, req.header('Idempotency-Key'), `${scope}:${req.params.id ?? ''}`, (c) => fn(c, user, req));
      if (result.replayed) res.setHeader('Idempotent-Replay', 'true');
      res.status(result.status).json(result.body);
    });

  app.post('/api/items', mutate('POST /items', (c, u, req) => items.createItem(c, u, req.body)));
  app.get('/api/items/:id', wrap(async (req, res) => res.json(await items.getItem(me(req), req.params.id))));
  app.patch('/api/items/:id', mutate('PATCH /items/:id', (c, u, req) => items.updateItem(c, u, req.params.id, req.body)));
  app.post('/api/items/:id/claim', mutate('POST /items/:id/claim', (c, u, req) => items.claimItem(c, u, req.params.id)));
  app.post('/api/items/:id/transition', mutate('POST /items/:id/transition', (c, u, req) => items.transitionItem(c, u, req.params.id, req.body)));
  app.post('/api/items/:id/comments', mutate('POST /items/:id/comments', (c, u, req) => items.addComment(c, u, req.params.id, req.body)));
  app.get('/api/items/:id/activity', wrap(async (req, res) =>
    res.json(await items.getActivity(me(req), req.params.id, req.query.cursor, req.query.limit))));

  app.use('/api', (_req, _res, next) => next(new AppError(404, 'not_found', 'Not found')));

  // Serve the built React app (Docker image copies it to ./public)
  if (fs.existsSync(path.join(config.staticDir, 'index.html'))) {
    app.use(express.static(config.staticDir));
    app.use((req, res, next) =>
      req.method === 'GET' ? res.sendFile(path.join(config.staticDir, 'index.html')) : next());
  }

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof AppError) {
      return res.status(err.status).json({ error: err.code, message: err.message, ...err.extra });
    }
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'bad_json', message: 'Invalid JSON body' });
    console.error(err);
    res.status(500).json({ error: 'internal_error', message: 'Something went wrong' });
  });

  return app;
}
