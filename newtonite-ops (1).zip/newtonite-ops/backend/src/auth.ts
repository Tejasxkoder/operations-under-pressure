import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import type { Request, RequestHandler } from 'express';
import { config } from './config';
import { pool } from './db';
import { AppError } from './errors';
import type { AuthUser } from './permissions';

const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 8);

export function signToken(userId: string): string {
  return jwt.sign({ sub: userId }, config.jwtSecret, { expiresIn: '12h' });
}

export async function loadUser(id: string): Promise<AuthUser | null> {
  const u = await pool.query('SELECT id, name, email FROM users WHERE id = $1', [id]);
  if (!u.rows[0]) return null;
  const m = await pool.query(
    `SELECT m.team_id, t.name AS team_name, m.role FROM memberships m
     JOIN teams t ON t.id = m.team_id WHERE m.user_id = $1 ORDER BY t.name`,
    [id],
  );
  return {
    ...u.rows[0],
    memberships: m.rows.map((r: any) => ({ teamId: r.team_id, teamName: r.team_name, role: r.role })),
  };
}

export async function login(email: unknown, password: unknown): Promise<{ token: string }> {
  if (typeof email !== 'string' || typeof password !== 'string') {
    throw new AppError(400, 'validation_error', 'email and password are required');
  }
  const r = await pool.query('SELECT id, password_hash FROM users WHERE lower(email) = lower($1)', [email]);
  const row = r.rows[0];
  const ok = await bcrypt.compare(password, row ? row.password_hash : DUMMY_HASH);
  if (!row || !ok) throw new AppError(401, 'invalid_credentials', 'Invalid email or password');
  return { token: signToken(row.id) };
}

// Loads the caller (with fresh team roles from the DB on every request).
export const authenticate: RequestHandler = async (req, _res, next) => {
  let userId: string;
  try {
    const header = req.header('Authorization') ?? '';
    if (!header.startsWith('Bearer ')) throw new Error('no token');
    userId = (jwt.verify(header.slice(7), config.jwtSecret) as { sub: string }).sub;
  } catch {
    return next(new AppError(401, 'unauthorized', 'Missing or invalid token'));
  }
  try {
    const user = await loadUser(userId);
    if (!user) return next(new AppError(401, 'unauthorized', 'User no longer exists'));
    (req as any).user = user;
    next();
  } catch (e) {
    next(e);
  }
};

export const me = (req: Request) => (req as any).user as AuthUser;
