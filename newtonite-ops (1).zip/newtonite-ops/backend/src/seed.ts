import bcrypt from 'bcryptjs';
import { pool } from './db';
import { migrate } from './migrate';

export const DEMO_PASSWORD = 'Passw0rd!';

const TEAMS = ['Payments Ops', 'Customer Support', 'Compliance'];
// [name, email, { team: role }]
const USERS: Array<[string, string, Record<string, string>]> = [
  ['Asha Admin', 'admin@ops.test', { 'Payments Ops': 'admin', 'Customer Support': 'admin', Compliance: 'admin' }],
  ['Priya Lead', 'priya.lead@ops.test', { 'Payments Ops': 'lead', 'Customer Support': 'member' }],
  ['Rahul Lead', 'rahul.lead@ops.test', { 'Customer Support': 'lead' }],
  ['Meera Lead', 'meera.lead@ops.test', { Compliance: 'lead' }],
  ['Amit Member', 'amit.member@ops.test', { 'Payments Ops': 'member', 'Customer Support': 'member' }],
  ['Neha Member', 'neha.member@ops.test', { 'Payments Ops': 'member' }],
  ['Sara Member', 'sara.member@ops.test', { 'Customer Support': 'member' }],
  ['Dev Member', 'dev.member@ops.test', { Compliance: 'member' }],
  ['Zoya Member', 'zoya.member@ops.test', { Compliance: 'member' }],
  ['Ravi Viewer', 'ravi.viewer@ops.test', { 'Payments Ops': 'viewer' }],
];

export async function seed(itemCount = 3000) {
  await migrate();
  await pool.query('TRUNCATE users, teams, memberships, work_items, activity_events, idempotency_keys, jobs, notifications RESTART IDENTITY CASCADE');
  const hash = bcrypt.hashSync(DEMO_PASSWORD, 8);

  const teamIds: Record<string, string> = {};
  for (const t of TEAMS) {
    teamIds[t] = (await pool.query('INSERT INTO teams (name) VALUES ($1) RETURNING id', [t])).rows[0].id;
  }
  for (const [name, email, roles] of USERS) {
    const uid = (await pool.query('INSERT INTO users (email, name, password_hash) VALUES ($1,$2,$3) RETURNING id', [email, name, hash])).rows[0].id;
    for (const [team, role] of Object.entries(roles)) {
      await pool.query('INSERT INTO memberships (user_id, team_id, role) VALUES ($1,$2,$3)', [uid, teamIds[team], role]);
    }
  }

  const perTeam = Math.floor(itemCount / TEAMS.length);
  for (const t of TEAMS) {
    const members = (await pool.query(
      `SELECT user_id FROM memberships WHERE team_id = $1 AND role <> 'viewer' ORDER BY user_id`, [teamIds[t]])).rows.map((r: any) => r.user_id);
    await pool.query(
      `INSERT INTO work_items (title, description, type, priority, status, team_id, assignee_id, created_by, due_date, created_at, updated_at)
       SELECT x.ti || ' #' || x.g, 'Auto-generated sample item ' || x.g || ' for load testing and pagination.',
              x.ty, x.p, x.s, $1::uuid,
              CASE WHEN x.s = 'open' THEN NULL ELSE ($3::uuid[])[1 + x.mi] END,
              ($3::uuid[])[1 + ((x.mi + 1) % $4::int)],
              current_date + (x.d - 10),
              now() - (x.d || ' days')::interval - (x.g || ' minutes')::interval,
              now() - (x.d || ' days')::interval - (x.g || ' minutes')::interval
       FROM (
         SELECT g,
           (ARRAY['open','open','in_progress','in_progress','awaiting_approval','resolved','closed'])[1 + floor(random()*7)::int] AS s,
           (ARRAY['low','medium','medium','high','urgent'])[1 + floor(random()*5)::int] AS p,
           (ARRAY['incident','customer_issue','payment','compliance','task'])[1 + floor(random()*5)::int] AS ty,
           (ARRAY['Payment failed','Chargeback dispute','KYC review','Service outage','Refund request','Audit finding'])[1 + floor(random()*6)::int] AS ti,
           floor(random() * $4::int)::int AS mi,
           floor(random() * 30)::int AS d
         FROM generate_series(1, $2::int) g
       ) x`,
      [teamIds[t], perTeam, members, members.length],
    );
  }
  await pool.query(`INSERT INTO activity_events (item_id, actor_id, kind, data)
                    SELECT id, created_by, 'created', jsonb_build_object('title', title, 'type', type, 'priority', priority) FROM work_items`);
  console.log(`Seeded ${TEAMS.length} teams, ${USERS.length} users, ${perTeam * TEAMS.length} items. Password for all users: ${DEMO_PASSWORD}`);
}

if (process.argv[1] && process.argv[1].endsWith('seed.ts')) {
  (async () => {
    await migrate();
    if (process.argv.includes('--if-empty')) {
      const { rows } = await pool.query('SELECT count(*)::int AS n FROM users');
      if (rows[0].n > 0) { console.log('Database already seeded, skipping'); return; }
    }
    await seed();
  })().catch((e) => { console.error(e); process.exit(1); }).finally(() => pool.end());
}
