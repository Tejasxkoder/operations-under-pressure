import { AppError } from './errors';
import type { Role, Status } from './domain';

export const ROLE_RANK: Record<Role, number> = { viewer: 1, member: 2, lead: 3, admin: 4 };

export type Action =
  | 'item:read' | 'item:create' | 'item:edit' | 'item:comment'
  | 'item:claim' | 'item:assign' | 'item:transition' | 'item:approve';

// Role x action matrix: the minimum role (in the item's team) needed per action.
export const MIN_ROLE: Record<Action, Role> = {
  'item:read': 'viewer',
  'item:create': 'member',
  'item:edit': 'member',
  'item:comment': 'member',
  'item:claim': 'member',
  'item:transition': 'member',
  'item:assign': 'lead',     // assign / reassign others
  'item:approve': 'lead',    // approval step + closing + reopening
};

// Workflow: allowed transitions and the action each one requires.
export const TRANSITIONS: Record<Status, Partial<Record<Status, Action>>> = {
  open: { in_progress: 'item:transition' },
  in_progress: { open: 'item:transition', awaiting_approval: 'item:transition' },
  awaiting_approval: { resolved: 'item:approve', in_progress: 'item:approve' },
  resolved: { closed: 'item:approve', in_progress: 'item:approve' },
  closed: {},
};

export interface Membership { teamId: string; teamName: string; role: Role }
export interface AuthUser { id: string; name: string; email: string; memberships: Membership[] }

export function roleIn(user: AuthUser, teamId: string): Role | null {
  return user.memberships.find((m) => m.teamId === teamId)?.role ?? null;
}

// THE single permission check. Every endpoint goes through assertCan().
export function can(user: AuthUser, teamId: string, action: Action): boolean {
  const role = roleIn(user, teamId);
  return role !== null && ROLE_RANK[role] >= ROLE_RANK[MIN_ROLE[action]];
}

export function assertCan(user: AuthUser, teamId: string, action: Action): void {
  if (!can(user, teamId, action)) {
    const need = MIN_ROLE[action];
    throw new AppError(403, 'forbidden', `You need the ${need} role (or higher) in this team to do that.`);
  }
}
