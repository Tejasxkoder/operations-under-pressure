import path from 'node:path';

export const config = {
  databaseUrl: process.env.DATABASE_URL ?? 'postgres://ops:ops@localhost:5432/ops',
  jwtSecret: process.env.JWT_SECRET ?? 'dev-only-secret-change-me',
  port: Number(process.env.PORT ?? 3000),
  staticDir: process.env.STATIC_DIR ?? path.resolve(process.cwd(), 'public'),
  workerIntervalMs: Number(process.env.WORKER_INTERVAL_MS ?? 2000),
  runWorker: process.env.RUN_WORKER !== 'false',
};
