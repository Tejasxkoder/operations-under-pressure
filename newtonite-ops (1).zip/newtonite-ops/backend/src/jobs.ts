import { pool, type Db } from './db';

export interface Job { id: number; type: string; payload: any; attempts: number; max_attempts: number }
export type Handler = (db: Db, payload: any, job: Job) => Promise<void>;

// Idempotent: notifications.job_id is UNIQUE, so running a job twice yields one notification.
export const defaultHandlers: Record<string, Handler> = {
  notify_assignee: async (db, p, job) => {
    await db.query(
      `INSERT INTO notifications (job_id, user_id, item_id, message) VALUES ($1, $2, $3, $4)
       ON CONFLICT (job_id) DO NOTHING`,
      [job.id, p.assigneeId, p.itemId, `You were assigned: ${p.title}`],
    );
  },
};

export async function enqueue(db: Db, type: string, payload: unknown): Promise<void> {
  await db.query('INSERT INTO jobs (type, payload) VALUES ($1, $2)', [type, JSON.stringify(payload)]);
}

/** Claims due jobs (SKIP LOCKED => safe with several workers), runs them, retries with backoff. */
export async function processJobs(handlers: Record<string, Handler> = defaultHandlers, batch = 10) {
  const stats = { done: 0, retried: 0, failed: 0 };
  // A worker that crashed mid-job leaves 'processing' rows behind: put them back.
  await pool.query(
    `UPDATE jobs SET status = 'pending' WHERE status = 'processing' AND locked_at < now() - interval '60 seconds'`,
  );
  const { rows } = await pool.query(
    `UPDATE jobs SET status = 'processing', locked_at = now(), attempts = attempts + 1
     WHERE id IN (SELECT id FROM jobs WHERE status = 'pending' AND run_at <= now()
                  ORDER BY id LIMIT $1 FOR UPDATE SKIP LOCKED)
     RETURNING *`,
    [batch],
  );
  for (const job of rows as Job[]) {
    try {
      const handler = handlers[job.type];
      if (!handler) throw new Error(`No handler for job type ${job.type}`);
      await handler(pool, job.payload, job);
      await pool.query(`UPDATE jobs SET status = 'done', processed_at = now(), last_error = NULL WHERE id = $1`, [job.id]);
      stats.done++;
    } catch (e: any) {
      const message = String(e?.message ?? e).slice(0, 500);
      if (job.attempts >= job.max_attempts) {
        await pool.query(`UPDATE jobs SET status = 'failed', last_error = $2 WHERE id = $1`, [job.id, message]);
        stats.failed++;
      } else {
        const backoffSeconds = Math.min(2 ** job.attempts, 300); // exponential backoff
        await pool.query(
          `UPDATE jobs SET status = 'pending', last_error = $2, run_at = now() + make_interval(secs => $3) WHERE id = $1`,
          [job.id, message, backoffSeconds],
        );
        stats.retried++;
      }
    }
  }
  return stats;
}

export function startWorker(intervalMs: number): () => void {
  let running = false;
  const timer = setInterval(async () => {
    if (running) return;
    running = true;
    try { await processJobs(); } catch (e) { console.error('worker error', e); } finally { running = false; }
  }, intervalMs);
  return () => clearInterval(timer);
}
