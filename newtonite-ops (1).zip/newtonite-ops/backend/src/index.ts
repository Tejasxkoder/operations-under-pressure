import { createApp } from './app';
import { config } from './config';
import { startWorker } from './jobs';

const app = createApp();
app.listen(config.port, () => console.log(`API listening on http://localhost:${config.port}`));
if (config.runWorker) {
  startWorker(config.workerIntervalMs); // background outbox worker (same process; can be split out)
  console.log('Outbox worker started');
}
