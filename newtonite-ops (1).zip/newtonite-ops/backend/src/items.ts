import type { PoolClient } from 'pg';
import { pool, type Db } from './db';
import { AppError } from './errors';
import { enqueue } from './jobs';
import type { Result } from './idempotency';
import { PRIORITIES, STATUSES, TYPES } from './domain';
import { assertCan, can, roleIn, ROLE_RANK, TRANSITIONS, type AuthUser } from './permissions';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isUuid = (v: unknown): v is string => typeof v === 'string' && UUID.test(v);
const bad = (m: string) => new AppError(400, 'validation_error', m);

const ITEM_SELECT = `
  SELECT w.id, w.title, w.description, w.type, w.priority, w.status, w.team_id, t.name AS team_name,
         w.assignee_id, a.name AS assignee_name, w.created_by, w.due_date, w.version, w.created_at, w.updated_at, w.seq
  FROM work_items w JOIN teams t ON t.id = w.team_id LEFT JOIN users a ON a.id = w.assignee_id`;

function mapItem(r: any) {
  return {
    id: r.id, title: r.title, description: r.description, type: r.type, priority: r.priority,
    status: r.status, teamId: r.team_id, teamName: r.team_name, assigneeId: r.assignee_id,
    assigneeName: r.assignee_name, createdBy: r.created_by, dueDate: r.due_date, version: r.version,
    createdAt: r.created_at, updatedAt: r.updated_at,
  };
}
type ItemDto = ReturnType<typeof mapItem>;

async function fetchItem(db: Db, id: string): Promise<ItemDto | null> {
  const { rows } = await db.query(`${ITEM_SELECT} WHERE w.id = $1`, [id]);
  return rows[0] ? mapItem(rows[0]) : null;
}

async function loadForAction(db: Db, user: AuthUser, id: string, action: Parameters<typeof assertCan>[2]) {
  if (!isUuid(id)) throw new AppError(404, 'not_found', 'Item not found');
  const item = await fetchItem(db, id);
  if (!item) throw new AppError(404, 'not_found', 'Item not found');
  assertCan(user, item.teamId, action); // server-side, per team and per resource
  return item;
}

const conflict = (latest: ItemDto | null) =>
  new AppError(409, 'version_conflict', 'This item was changed by someone else.', { latest });

async function logEvent(db: Db, itemId: string, actorId: string, kind: string, data: unknown = {}) {
  await db.query('INSERT INTO activity_events (item_id, actor_id, kind, data) VALUES ($1, $2, $3, $4)', [
    itemId, actorId, kind, JSON.stringify(data),
  ]);
}

async function assertAssignable(db: Db, userId: string, teamId: string) {
  const { rows } = await db.query(
    `SELECT u.name, m.role FROM memberships m JOIN users u ON u.id = m.user_id WHERE m.user_id = $1 AND m.team_id = $2`,
    [userId, teamId],
  );
  if (!rows[0] || rows[0].role === 'viewer') throw bad('Assignee must be a non-viewer member of the item\'s team');
  return rows[0].name as string;
}

const reqStr = (v: unknown, name: string, max: number) => {
  if (typeof v !== 'string' || v.trim().length === 0) throw bad(`${name} is required`);
  if (v.length > max) throw bad(`${name} is too long (max ${max})`);
  return v.trim();
};
const oneOf = <T extends string>(v: unknown, list: readonly T[], name: string): T => {
  if (typeof v !== 'string' || !list.includes(v as T)) throw bad(`${name} must be one of: ${list.join(', ')}`);
  return v as T;
};
const dateOrNull = (v: unknown) => {
  if (v === null || v === undefined || v === '') return null;
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || isNaN(Date.parse(v))) throw bad('dueDate must be YYYY-MM-DD');
  return v;
};

// ---------- create ----------
export async function createItem(c: PoolClient, user: AuthUser, b: any): Promise<Result> {
  const title = reqStr(b?.title, 'title', 200);
  const description = b?.description == null || b.description === '' ? '' : reqStr(b.description, 'description', 5000);
  const type = oneOf(b?.type ?? 'task', TYPES, 'type');
  const priority = oneOf(b?.priority ?? 'medium', PRIORITIES, 'priority');
  if (!isUuid(b?.teamId)) throw bad('teamId is required');
  const teamId: string = b.teamId;
  assertCan(user, teamId, 'item:create');
  const dueDate = dateOrNull(b?.dueDate);

  let assigneeId: string | null = null;
  let assigneeName: string | null = null;
  if (b?.assigneeId) {
    if (!isUuid(b.assigneeId)) throw bad('assigneeId invalid');
    assertCan(user, teamId, 'item:assign');
    assigneeName = await assertAssignable(c, b.assigneeId, teamId);
    assigneeId = b.assigneeId;
  }

  const { rows } = await c.query(
    `INSERT INTO work_items (title, description, type, priority, team_id, assignee_id, created_by, due_date)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [title, description, type, priority, teamId, assigneeId, user.id, dueDate],
  );
  const id = rows[0].id as string;
  await logEvent(c, id, user.id, 'created', { title, type, priority });
  if (assigneeId) {
    await logEvent(c, id, user.id, 'assignee_changed', { from: null, to: assigneeId, toName: assigneeName });
    await enqueue(c, 'notify_assignee', { itemId: id, assigneeId, title });
  }
  return { status: 201, body: { item: await fetchItem(c, id) } };
}

// ---------- read ----------
export async function getItem(user: AuthUser, id: string) {
  const item = await loadForAction(pool, user, id, 'item:read');
  const allowedTransitions = Object.entries(TRANSITIONS[item.status as keyof typeof TRANSITIONS])
    .filter(([, action]) => can(user, item.teamId, action!))
    .map(([to]) => to);
  return { item, role: roleIn(user, item.teamId), allowedTransitions };
}

// ---------- update (optimistic locking) ----------
export async function updateItem(c: PoolClient, user: AuthUser, id: string, b: any): Promise<Result> {
  const item = await loadForAction(c, user, id, 'item:edit');
  if (!Number.isInteger(b?.version)) throw bad('version is required');
  if (item.status === 'closed') throw new AppError(409, 'item_closed', 'Closed items cannot be edited.', { latest: item });
  if (item.version !== b.version) throw conflict(item);

  const sets: string[] = [];
  const params: any[] = [];
  const set = (col: string, v: unknown) => { params.push(v); sets.push(`${col} = $${params.length}`); };
  const events: Array<[string, unknown]> = [];
  const plainFields: string[] = [];

  if ('title' in b) { set('title', reqStr(b.title, 'title', 200)); plainFields.push('title'); }
  if ('description' in b) { set('description', b.description ? reqStr(b.description, 'description', 5000) : ''); plainFields.push('description'); }
  if ('type' in b) { set('type', oneOf(b.type, TYPES, 'type')); plainFields.push('type'); }
  if ('dueDate' in b) { set('due_date', dateOrNull(b.dueDate)); plainFields.push('dueDate'); }
  if ('priority' in b) {
    const priority = oneOf(b.priority, PRIORITIES, 'priority');
    if (priority !== item.priority) { set('priority', priority); events.push(['priority_changed', { from: item.priority, to: priority }]); }
  }
  if ('assigneeId' in b) {
    assertCan(user, item.teamId, 'item:assign'); // reassigning needs Lead
    const next = b.assigneeId ? b.assigneeId : null;
    if (next !== null && !isUuid(next)) throw bad('assigneeId invalid');
    if (next !== item.assigneeId) {
      const toName = next ? await assertAssignable(c, next, item.teamId) : null;
      set('assignee_id', next);
      events.push(['assignee_changed', { from: item.assigneeId, fromName: item.assigneeName, to: next, toName }]);
      if (next) await enqueue(c, 'notify_assignee', { itemId: id, assigneeId: next, title: item.title });
    }
  }
  if (sets.length === 0) throw bad('Nothing to update');
  if (plainFields.length) events.unshift(['updated', { fields: plainFields }]);

  params.push(id, b.version);
  const { rowCount } = await c.query(
    `UPDATE work_items SET ${sets.join(', ')}, version = version + 1, updated_at = now()
     WHERE id = $${params.length - 1} AND version = $${params.length}`,
    params,
  );
  if (rowCount === 0) throw conflict(await fetchItem(c, id)); // lost the race: transaction rolls back
  for (const [kind, data] of events) await logEvent(c, id, user.id, kind, data);
  return { status: 200, body: { item: await fetchItem(c, id) } };
}

// ---------- claim (atomic conditional update) ----------
export async function claimItem(c: PoolClient, user: AuthUser, id: string): Promise<Result> {
  const before = await loadForAction(c, user, id, 'item:claim');
  const { rows } = await c.query(
    `UPDATE work_items
        SET assignee_id = $1,
            status = CASE WHEN status = 'open' THEN 'in_progress' ELSE status END,
            version = version + 1, updated_at = now()
      WHERE id = $2 AND assignee_id IS NULL AND status IN ('open', 'in_progress')
      RETURNING status`,
    [user.id, id],
  );
  if (rows.length === 0) {
    throw new AppError(409, 'already_claimed', 'Someone else already claimed this item (or it can no longer be claimed).', {
      latest: await fetchItem(c, id),
    });
  }
  await logEvent(c, id, user.id, 'assignee_changed', { from: null, to: user.id, toName: user.name, via: 'claim' });
  if (before.status !== rows[0].status) {
    await logEvent(c, id, user.id, 'status_changed', { from: before.status, to: rows[0].status });
  }
  return { status: 200, body: { item: await fetchItem(c, id) } };
}

// ---------- workflow transitions ----------
export async function transitionItem(c: PoolClient, user: AuthUser, id: string, b: any): Promise<Result> {
  const item = await loadForAction(c, user, id, 'item:read');
  const to = oneOf(b?.to, STATUSES, 'to');
  const required = TRANSITIONS[item.status as keyof typeof TRANSITIONS][to];
  if (!required) {
    throw new AppError(422, 'invalid_transition', `Cannot move from "${item.status}" to "${to}".`, {
      allowed: Object.keys(TRANSITIONS[item.status as keyof typeof TRANSITIONS]),
    });
  }
  assertCan(user, item.teamId, required); // e.g. approval => Lead of THIS team
  if (b.version !== undefined && b.version !== item.version) throw conflict(item);

  const { rowCount } = await c.query(
    `UPDATE work_items SET status = $1, version = version + 1, updated_at = now()
     WHERE id = $2 AND status = $3`,
    [to, id, item.status],
  );
  if (rowCount === 0) throw conflict(await fetchItem(c, id));
  await logEvent(c, id, user.id, 'status_changed', { from: item.status, to });
  return { status: 200, body: { item: await fetchItem(c, id) } };
}

// ---------- comments ----------
export async function addComment(c: PoolClient, user: AuthUser, id: string, b: any): Promise<Result> {
  const item = await loadForAction(c, user, id, 'item:comment');
  const body = reqStr(b?.body, 'body', 2000);
  await logEvent(c, item.id, user.id, 'comment', { body });
  return { status: 201, body: { ok: true } };
}

// ---------- activity ----------
export async function getActivity(user: AuthUser, id: string, cursor: unknown, limitRaw: unknown) {
  await loadForAction(pool, user, id, 'item:read');
  const limit = Math.min(Math.max(parseInt(String(limitRaw ?? '100'), 10) || 100, 1), 200);
  const after = parseInt(String(cursor ?? '0'), 10) || 0;
  const { rows } = await pool.query(
    `SELECT e.id, e.kind, e.data, e.created_at, e.actor_id, u.name AS actor_name
       FROM activity_events e LEFT JOIN users u ON u.id = e.actor_id
      WHERE e.item_id = $1 AND e.id > $2 ORDER BY e.id ASC LIMIT $3`,
    [id, after, limit + 1],
  );
  const more = rows.length > limit;
  const page = more ? rows.slice(0, limit) : rows;
  return {
    events: page.map((r: any) => ({ id: r.id, kind: r.kind, data: r.data, createdAt: r.created_at, actorId: r.actor_id, actorName: r.actor_name })),
    nextCursor: more ? String(page[page.length - 1].id) : null,
  };
}

// ---------- list: server-side filter, search, cursor pagination ----------
export async function listItems(user: AuthUser, q: Record<string, any>) {
  const teamIds = user.memberships.map((m) => m.teamId);
  const leadTeamIds = user.memberships.filter((m) => ROLE_RANK[m.role] >= ROLE_RANK.lead).map((m) => m.teamId);
  const params: any[] = [teamIds];
  const where: string[] = ['w.team_id = ANY($1::uuid[])']; // scope: only my teams
  const p = (v: unknown) => { params.push(v); return `$${params.length}`; };
  const open = `w.status NOT IN ('resolved','closed')`;

  switch (q.view) {
    case undefined: case '': case 'all': break;
    case 'assigned_to_me': where.push(`w.assignee_id = ${p(user.id)} AND ${open}`); break;
    case 'unassigned_urgent': where.push(`w.assignee_id IS NULL AND w.priority = 'urgent' AND ${open}`); break;
    case 'awaiting_my_approval': where.push(`w.status = 'awaiting_approval' AND w.team_id = ANY(${p(leadTeamIds)}::uuid[])`); break;
    default: throw bad('unknown view');
  }
  if (q.status) where.push(`w.status = ${p(oneOf(q.status, STATUSES, 'status'))}`);
  if (q.priority) where.push(`w.priority = ${p(oneOf(q.priority, PRIORITIES, 'priority'))}`);
  if (q.type) where.push(`w.type = ${p(oneOf(q.type, TYPES, 'type'))}`);
  if (q.teamId) { if (!isUuid(q.teamId)) throw bad('teamId invalid'); where.push(`w.team_id = ${p(q.teamId)}`); }
  if (q.assignee === 'me') where.push(`w.assignee_id = ${p(user.id)}`);
  else if (q.assignee === 'unassigned') where.push('w.assignee_id IS NULL');
  else if (q.assignee) { if (!isUuid(q.assignee)) throw bad('assignee invalid'); where.push(`w.assignee_id = ${p(q.assignee)}`); }
  if (typeof q.q === 'string' && q.q.trim()) where.push(`w.search @@ plainto_tsquery('english', ${p(q.q.trim().slice(0, 100))})`);
  if (q.cursor) {
    const c = parseInt(String(q.cursor), 10);
    if (!Number.isFinite(c)) throw bad('cursor invalid');
    where.push(`w.seq < ${p(c)}`);
  }
  const limit = Math.min(Math.max(parseInt(String(q.limit ?? '20'), 10) || 20, 1), 100);

  const { rows } = await pool.query(
    `${ITEM_SELECT} WHERE ${where.join(' AND ')} ORDER BY w.seq DESC LIMIT ${p(limit + 1)}`,
    params,
  );
  const more = rows.length > limit;
  const page = more ? rows.slice(0, limit) : rows;
  return { items: page.map(mapItem), nextCursor: more ? String(page[page.length - 1].seq) : null };
}

export async function listTeamUsers(user: AuthUser) {
  const { rows } = await pool.query(
    `SELECT u.id, u.name, m.team_id, m.role FROM memberships m JOIN users u ON u.id = m.user_id
      WHERE m.team_id = ANY($1::uuid[]) ORDER BY u.name`,
    [user.memberships.map((m) => m.teamId)],
  );
  return rows.map((r: any) => ({ id: r.id, name: r.name, teamId: r.team_id, role: r.role }));
}
