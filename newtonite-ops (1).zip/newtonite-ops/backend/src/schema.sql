CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS memberships (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  team_id uuid NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('viewer','member','lead','admin')),
  PRIMARY KEY (user_id, team_id)
);

CREATE TABLE IF NOT EXISTS work_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seq bigserial UNIQUE NOT NULL,                       -- stable, gap-tolerant cursor key
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 200),
  description text NOT NULL DEFAULT '',
  type text NOT NULL CHECK (type IN ('incident','customer_issue','payment','compliance','task')),
  priority text NOT NULL CHECK (priority IN ('low','medium','high','urgent')),
  status text NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','in_progress','awaiting_approval','resolved','closed')),
  team_id uuid NOT NULL REFERENCES teams(id),
  assignee_id uuid REFERENCES users(id),
  created_by uuid NOT NULL REFERENCES users(id),
  due_date date,
  version integer NOT NULL DEFAULT 1,                  -- optimistic locking
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  search tsvector GENERATED ALWAYS AS (to_tsvector('english', title || ' ' || description)) STORED
);

CREATE INDEX IF NOT EXISTS idx_items_team_seq ON work_items (team_id, seq DESC);
CREATE INDEX IF NOT EXISTS idx_items_assignee_seq ON work_items (assignee_id, seq DESC);
CREATE INDEX IF NOT EXISTS idx_items_status_team_seq ON work_items (status, team_id, seq DESC);
CREATE INDEX IF NOT EXISTS idx_items_unassigned_urgent ON work_items (seq DESC)
  WHERE assignee_id IS NULL AND priority = 'urgent' AND status NOT IN ('resolved','closed');
CREATE INDEX IF NOT EXISTS idx_items_search ON work_items USING gin (search);

-- Comments live here too (kind = 'comment'); one append-only timeline per item.
CREATE TABLE IF NOT EXISTS activity_events (
  id bigserial PRIMARY KEY,
  item_id uuid NOT NULL REFERENCES work_items(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES users(id),
  kind text NOT NULL,
  data jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_activity_item_id ON activity_events (item_id, id);

CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'activity_events is append-only';
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS activity_events_append_only ON activity_events;
CREATE TRIGGER activity_events_append_only
  BEFORE UPDATE OR DELETE ON activity_events
  FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

CREATE TABLE IF NOT EXISTS idempotency_keys (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key text NOT NULL,
  scope text NOT NULL,
  status_code integer,
  response jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, key)
);

CREATE TABLE IF NOT EXISTS jobs (
  id bigserial PRIMARY KEY,
  type text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','processing','done','failed')),
  attempts integer NOT NULL DEFAULT 0,
  max_attempts integer NOT NULL DEFAULT 5,
  run_at timestamptz NOT NULL DEFAULT now(),
  locked_at timestamptz,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_jobs_pending ON jobs (status, run_at);

CREATE TABLE IF NOT EXISTS notifications (
  id bigserial PRIMARY KEY,
  job_id bigint UNIQUE NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,  -- makes the handler idempotent
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_id uuid,
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
