export const ROLES = ['viewer', 'member', 'lead', 'admin'] as const;
export const TYPES = ['incident', 'customer_issue', 'payment', 'compliance', 'task'] as const;
export const PRIORITIES = ['low', 'medium', 'high', 'urgent'] as const;
export const STATUSES = ['open', 'in_progress', 'awaiting_approval', 'resolved', 'closed'] as const;
export type Role = (typeof ROLES)[number];
export type Status = (typeof STATUSES)[number];
