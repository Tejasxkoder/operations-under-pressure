export type Role = 'viewer' | 'member' | 'lead' | 'admin';
export interface Membership { teamId: string; teamName: string; role: Role }
export interface Me { user: { id: string; name: string; email: string }; memberships: Membership[] }
export interface Item {
  id: string; title: string; description: string; type: string; priority: string; status: string;
  teamId: string; teamName: string; assigneeId: string | null; assigneeName: string | null;
  createdBy: string; dueDate: string | null; version: number; createdAt: string; updatedAt: string;
}
export interface ItemDetail { item: Item; role: Role | null; allowedTransitions: string[] }
export interface ActivityEvent { id: number; kind: string; data: any; createdAt: string; actorName: string | null }
export interface TeamUser { id: string; name: string; teamId: string; role: Role }

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public latest?: Item) {
    super(message);
  }
}

let token: string | null = localStorage.getItem('ops_token');
export const getToken = () => token;
export function setToken(t: string | null) {
  token = t;
  if (t) localStorage.setItem('ops_token', t);
  else localStorage.removeItem('ops_token');
}

export const uuid = (): string =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : 'k-' + Date.now() + '-' + Math.random().toString(36).slice(2);

export async function api<T = any>(
  path: string,
  opts: { method?: string; body?: unknown; idemKey?: string } = {},
): Promise<T> {
  const headers: Record<string, string> = {};
  if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = 'Bearer ' + token;
  if (opts.idemKey) headers['Idempotency-Key'] = opts.idemKey;
  const res = await fetch('/api' + path, {
    method: opts.method ?? 'GET',
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, data.error ?? 'error', data.message ?? res.statusText, data.latest);
  return data as T;
}
