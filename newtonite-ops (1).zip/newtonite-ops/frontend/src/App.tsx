import { useCallback, useEffect, useRef, useState } from 'react';
import {
  api, ApiError, getToken, setToken, uuid,
  type ActivityEvent, type Item, type ItemDetail, type Me, type TeamUser,
} from './api';

const STATUSES = ['open', 'in_progress', 'awaiting_approval', 'resolved', 'closed'];
const PRIORITIES = ['low', 'medium', 'high', 'urgent'];
const TYPES = ['incident', 'customer_issue', 'payment', 'compliance', 'task'];
const label = (s: string) => s.replace(/_/g, ' ');
const fmt = (iso: string) => new Date(iso).toLocaleString();
const errMsg = (e: unknown) => (e instanceof ApiError ? e.message : 'Network error — please try again.');

const DEMO = [
  ['admin@ops.test', 'Admin (all teams)'], ['priya.lead@ops.test', 'Lead · Payments'],
  ['rahul.lead@ops.test', 'Lead · Support'], ['meera.lead@ops.test', 'Lead · Compliance'],
  ['amit.member@ops.test', 'Member · Payments+Support'], ['sara.member@ops.test', 'Member · Support'],
  ['ravi.viewer@ops.test', 'Viewer · Payments'],
];

export default function App() {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(!!getToken());

  useEffect(() => {
    if (!getToken()) return;
    api<Me>('/me').then(setMe).catch(() => setToken(null)).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="center">Loading…</div>;
  if (!me) return <Login onLogin={setMe} />;
  return <Shell me={me} onLogout={() => { setToken(null); setMe(null); }} />;
}

function Login({ onLogin }: { onLogin: (m: Me) => void }) {
  const [email, setEmail] = useState('priya.lead@ops.test');
  const [password, setPassword] = useState('Passw0rd!');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true); setError('');
    try {
      const { token } = await api<{ token: string }>('/auth/login', { method: 'POST', body: { email, password } });
      setToken(token);
      onLogin(await api<Me>('/me'));
    } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  }

  return (
    <div className="center">
      <form className="card login" onSubmit={submit}>
        <h2>Operations Under Pressure</h2>
        <p className="muted">Sign in with a seeded demo user (password for all: <code>Passw0rd!</code>)</p>
        {error && <div className="err">{error}</div>}
        <div className="field"><label>Email</label><input className="f" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div className="field"><label>Password</label><input className="f" type="password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        <button className="btn" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <div className="demo">
          {DEMO.map(([em, name]) => <button type="button" key={em} onClick={() => setEmail(em)}>{name}</button>)}
        </div>
      </form>
    </div>
  );
}

function Shell({ me, onLogout }: { me: Me; onLogout: () => void }) {
  const [selected, setSelected] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [tick, setTick] = useState(0);
  const [users, setUsers] = useState<TeamUser[]>([]);
  const refresh = useCallback(() => setTick((t) => t + 1), []);

  useEffect(() => { api<{ users: TeamUser[] }>('/users').then((r) => setUsers(r.users)).catch(() => {}); }, []);
  useEffect(() => { const t = setInterval(refresh, 30000); return () => clearInterval(t); }, [refresh]); // polling, no websockets

  const canCreate = me.memberships.some((m) => m.role !== 'viewer');
  return (
    <>
      <header className="top">
        <h1>Operations Under Pressure</h1>
        <span className="roles">{me.user.name} · {me.memberships.map((m) => `${m.teamName}: ${m.role}`).join(' | ')}</span>
        {canCreate && <button className="btn" onClick={() => setCreating(true)}>+ New item</button>}
        <button className="btn secondary" onClick={onLogout}>Sign out</button>
      </header>
      <main className={selected || creating ? '' : 'single'}>
        <Dashboard me={me} tick={tick} selected={selected} onSelect={(id) => { setCreating(false); setSelected(id); }} />
        {creating && (
          <CreateItem me={me} users={users} onClose={() => setCreating(false)}
            onCreated={(id) => { setCreating(false); setSelected(id); refresh(); }} />
        )}
        {selected && !creating && (
          <Detail key={selected} id={selected} me={me} users={users} onClose={() => setSelected(null)} onChanged={refresh} />
        )}
      </main>
    </>
  );
}

const VIEWS: Array<[string, string]> = [
  ['assigned_to_me', 'Assigned to me'], ['unassigned_urgent', 'Unassigned urgent'],
  ['awaiting_my_approval', 'Awaiting my approval'], ['all', 'All items'],
];

function Dashboard({ me, tick, selected, onSelect }: { me: Me; tick: number; selected: string | null; onSelect: (id: string) => void }) {
  const [view, setView] = useState('assigned_to_me');
  const [qInput, setQInput] = useState('');
  const [f, setF] = useState({ q: '', status: '', priority: '', type: '', teamId: '' });
  const [items, setItems] = useState<Item[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { const t = setTimeout(() => setF((x) => ({ ...x, q: qInput })), 300); return () => clearTimeout(t); }, [qInput]);

  const query = (c?: string | null) => {
    const p = new URLSearchParams();
    p.set('view', view);
    Object.entries(f).forEach(([k, v]) => v && p.set(k, v));
    if (c) p.set('cursor', c);
    p.set('limit', '20');
    return p.toString();
  };

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<{ items: Item[]; nextCursor: string | null }>('/items?' + query())
      .then((r) => { if (!cancelled) { setItems(r.items); setCursor(r.nextCursor); setError(''); } })
      .catch((e) => { if (!cancelled) setError(errMsg(e)); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, f.q, f.status, f.priority, f.type, f.teamId, tick]);

  async function loadMore() {
    if (!cursor || loading) return;
    setLoading(true);
    try {
      const r = await api<{ items: Item[]; nextCursor: string | null }>('/items?' + query(cursor));
      setItems((prev) => [...prev, ...r.items]); setCursor(r.nextCursor);
    } catch (e) { setError(errMsg(e)); } finally { setLoading(false); }
  }

  const sel = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <section>
      <div className="tabs">
        {VIEWS.map(([k, name]) => (
          <button key={k} className={'tab' + (view === k ? ' active' : '')} onClick={() => setView(k)}>{name}</button>
        ))}
      </div>
      <div className="filters">
        <input placeholder="Search title / description…" value={qInput} onChange={(e) => setQInput(e.target.value)} />
        <select value={f.status} onChange={sel('status')}><option value="">Any status</option>{STATUSES.map((s) => <option key={s} value={s}>{label(s)}</option>)}</select>
        <select value={f.priority} onChange={sel('priority')}><option value="">Any priority</option>{PRIORITIES.map((s) => <option key={s}>{s}</option>)}</select>
        <select value={f.type} onChange={sel('type')}><option value="">Any type</option>{TYPES.map((s) => <option key={s} value={s}>{label(s)}</option>)}</select>
        <select value={f.teamId} onChange={sel('teamId')}><option value="">All my teams</option>{me.memberships.map((m) => <option key={m.teamId} value={m.teamId}>{m.teamName}</option>)}</select>
      </div>
      {error && <div className="err">{error}</div>}
      <div className="card" style={{ padding: 8 }}>
        <table>
          <thead><tr><th>Title</th><th>Status</th><th>Priority</th><th>Team</th><th>Assignee</th><th>Due</th></tr></thead>
          <tbody>
            {items.map((i) => (
              <tr key={i.id} className={'row' + (selected === i.id ? ' sel' : '')} onClick={() => onSelect(i.id)}>
                <td>{i.title}<div className="muted" style={{ fontSize: 11 }}>{label(i.type)}</div></td>
                <td><span className={`badge s-${i.status}`}>{label(i.status)}</span></td>
                <td><span className={`badge p-${i.priority}`}>{i.priority}</span></td>
                <td>{i.teamName}</td>
                <td>{i.assigneeName ?? <span className="muted">Unassigned</span>}</td>
                <td>{i.dueDate ?? '—'}</td>
              </tr>
            ))}
            {!loading && items.length === 0 && <tr><td colSpan={6} className="muted">Nothing here. 🎉</td></tr>}
          </tbody>
        </table>
        {loading && <p className="muted" style={{ padding: 8 }}>Loading…</p>}
        {cursor && !loading && <div style={{ padding: 8 }}><button className="btn secondary" onClick={loadMore}>Load more</button></div>}
      </div>
    </section>
  );
}

function CreateItem({ me, users, onClose, onCreated }: { me: Me; users: TeamUser[]; onClose: () => void; onCreated: (id: string) => void }) {
  const teams = me.memberships.filter((m) => m.role !== 'viewer');
  const [form, setForm] = useState({ title: '', description: '', type: 'task', priority: 'medium', teamId: teams[0]?.teamId ?? '', dueDate: '', assigneeId: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const idemKey = useRef(uuid()); // same key for retries/double-clicks of THIS submission
  const isLead = me.memberships.find((m) => m.teamId === form.teamId)?.role;
  const canAssign = isLead === 'lead' || isLead === 'admin';
  const set = (k: string) => (e: React.ChangeEvent<any>) => setForm({ ...form, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true); setError('');
    try {
      const body: any = { ...form, dueDate: form.dueDate || null, assigneeId: canAssign && form.assigneeId ? form.assigneeId : undefined };
      const r = await api<{ item: Item }>('/items', { method: 'POST', body, idemKey: idemKey.current });
      onCreated(r.item.id);
    } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  }

  return (
    <aside className="card">
      <h2>New work item</h2>
      {error && <div className="err">{error}</div>}
      <form onSubmit={submit}>
        <div className="field"><label>Title</label><input className="f" value={form.title} onChange={set('title')} maxLength={200} required /></div>
        <div className="field"><label>Description</label><textarea className="f" rows={3} value={form.description} onChange={set('description')} /></div>
        <div className="grid2">
          <div className="field"><label>Team</label><select className="f" value={form.teamId} onChange={set('teamId')}>{teams.map((t) => <option key={t.teamId} value={t.teamId}>{t.teamName}</option>)}</select></div>
          <div className="field"><label>Type</label><select className="f" value={form.type} onChange={set('type')}>{TYPES.map((t) => <option key={t} value={t}>{label(t)}</option>)}</select></div>
          <div className="field"><label>Priority</label><select className="f" value={form.priority} onChange={set('priority')}>{PRIORITIES.map((t) => <option key={t}>{t}</option>)}</select></div>
          <div className="field"><label>Due date</label><input className="f" type="date" value={form.dueDate} onChange={set('dueDate')} /></div>
        </div>
        {canAssign && (
          <div className="field"><label>Assignee (Lead only)</label>
            <select className="f" value={form.assigneeId} onChange={set('assigneeId')}>
              <option value="">Unassigned</option>
              {users.filter((u) => u.teamId === form.teamId && u.role !== 'viewer').map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
          </div>
        )}
        <div className="row-actions">
          <button className="btn" disabled={busy}>{busy ? 'Creating…' : 'Create'}</button>
          <button type="button" className="btn secondary" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </aside>
  );
}

function describe(e: ActivityEvent): string {
  const d = e.data ?? {};
  switch (e.kind) {
    case 'created': return 'created this item';
    case 'status_changed': return `changed status: ${label(d.from)} → ${label(d.to)}`;
    case 'priority_changed': return `changed priority: ${d.from} → ${d.to}`;
    case 'assignee_changed': return d.to ? `assigned to ${d.toName ?? 'someone'}${d.via === 'claim' ? ' (claimed)' : ''}` : 'unassigned the item';
    case 'updated': return `edited ${(d.fields ?? []).join(', ')}`;
    case 'comment': return 'commented';
    default: return e.kind;
  }
}

function Detail({ id, me, users, onClose, onChanged }: { id: string; me: Me; users: TeamUser[]; onClose: () => void; onChanged: () => void }) {
  const [data, setData] = useState<ItemDetail | null>(null);
  const [events, setEvents] = useState<ActivityEvent[]>([]);
  const [evCursor, setEvCursor] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [comment, setComment] = useState('');
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState({ title: '', description: '', priority: 'medium', dueDate: '' });

  const load = useCallback(async () => {
    try {
      const [d, a] = await Promise.all([
        api<ItemDetail>(`/items/${id}`),
        api<{ events: ActivityEvent[]; nextCursor: string | null }>(`/items/${id}/activity`),
      ]);
      setData(d); setEvents(a.events); setEvCursor(a.nextCursor);
    } catch (e) { setError(errMsg(e)); }
  }, [id]);
  useEffect(() => { load(); }, [load]);

  async function loadMoreEvents() {
    if (!evCursor) return;
    const a = await api<{ events: ActivityEvent[]; nextCursor: string | null }>(`/items/${id}/activity?cursor=${evCursor}`);
    setEvents((p) => [...p, ...a.events]); setEvCursor(a.nextCursor);
  }

  // Optimistic update: apply immediately, roll back + show the server's reason if rejected.
  async function run(optimistic: ((d: ItemDetail) => ItemDetail) | null, req: () => Promise<unknown>) {
    if (busy || !data) return;
    setBusy(true); setError('');
    const previous = data;
    if (optimistic) setData(optimistic(data));
    try {
      await req();
    } catch (e) {
      setData(previous); // rollback
      if (e instanceof ApiError && e.status === 409) {
        setError(`This item changed — ${e.message} We reloaded the latest version; please review and try again.`);
      } else setError(errMsg(e));
    }
    await load();
    onChanged();
    setBusy(false);
  }

  if (!data) return <aside className="card">{error ? <div className="err">{error}</div> : 'Loading…'}<button className="btn secondary" onClick={onClose}>Close</button></aside>;
  const { item, role, allowedTransitions } = data;
  const canWrite = role === 'member' || role === 'lead' || role === 'admin';
  const canAssign = role === 'lead' || role === 'admin';
  const claimable = canWrite && !item.assigneeId && (item.status === 'open' || item.status === 'in_progress');
  const assignable = users.filter((u) => u.teamId === item.teamId && u.role !== 'viewer');

  return (
    <aside className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <h2>{item.title}</h2>
        <button className="btn secondary" onClick={onClose}>✕</button>
      </div>
      <div>
        <span className={`badge s-${item.status}`}>{label(item.status)}</span>{' '}
        <span className={`badge p-${item.priority}`}>{item.priority}</span>{' '}
        <span className="badge">{label(item.type)}</span>
      </div>
      {error && <div className="err" style={{ marginTop: 10 }}>{error}</div>}
      <p style={{ whiteSpace: 'pre-wrap' }}>{item.description || <span className="muted">No description.</span>}</p>
      <div className="muted">
        {item.teamName} · you are <b>{role}</b> here · v{item.version}<br />
        Assignee: {item.assigneeName ?? 'Unassigned'} · Due: {item.dueDate ?? '—'}
      </div>

      <div className="row-actions">
        {claimable && (
          <button className="btn" disabled={busy}
            onClick={() => run(
              (d) => ({ ...d, item: { ...d.item, assigneeId: me.user.id, assigneeName: me.user.name, status: d.item.status === 'open' ? 'in_progress' : d.item.status } }),
              () => api(`/items/${id}/claim`, { method: 'POST', idemKey: uuid() }),
            )}>Claim</button>
        )}
        {allowedTransitions.map((to) => (
          <button key={to} className={'btn' + (to === 'resolved' ? '' : ' secondary')} disabled={busy}
            onClick={() => run(
              (d) => ({ ...d, item: { ...d.item, status: to } }),
              () => api(`/items/${id}/transition`, { method: 'POST', body: { to, version: item.version }, idemKey: uuid() }),
            )}>
            {to === 'resolved' ? 'Approve → resolved' : `→ ${label(to)}`}
          </button>
        ))}
        {canWrite && !editing && item.status !== 'closed' && (
          <button className="btn secondary" onClick={() => { setDraft({ title: item.title, description: item.description, priority: item.priority, dueDate: item.dueDate ?? '' }); setEditing(true); }}>Edit</button>
        )}
      </div>

      {canAssign && item.status !== 'closed' && (
        <div className="field"><label>Reassign (Lead)</label>
          <select className="f" value={item.assigneeId ?? ''} disabled={busy}
            onChange={(e) => run(null, () => api(`/items/${id}`, { method: 'PATCH', body: { version: item.version, assigneeId: e.target.value || null } }))}>
            <option value="">Unassigned</option>
            {assignable.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        </div>
      )}

      {editing && (
        <form onSubmit={async (e) => {
          e.preventDefault();
          await run(null, () => api(`/items/${id}`, { method: 'PATCH', body: { version: item.version, ...draft, dueDate: draft.dueDate || null } }));
          setEditing(false);
        }}>
          <div className="field"><label>Title</label><input className="f" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} required /></div>
          <div className="field"><label>Description</label><textarea className="f" rows={3} value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} /></div>
          <div className="grid2">
            <div className="field"><label>Priority</label><select className="f" value={draft.priority} onChange={(e) => setDraft({ ...draft, priority: e.target.value })}>{PRIORITIES.map((p) => <option key={p}>{p}</option>)}</select></div>
            <div className="field"><label>Due</label><input className="f" type="date" value={draft.dueDate} onChange={(e) => setDraft({ ...draft, dueDate: e.target.value })} /></div>
          </div>
          <div className="row-actions"><button className="btn" disabled={busy}>Save</button><button type="button" className="btn secondary" onClick={() => setEditing(false)}>Cancel</button></div>
        </form>
      )}

      <h3>Activity</h3>
      <ul className="timeline">
        {events.map((e) => (
          <li key={e.id}>
            <b>{e.actorName ?? 'System'}</b> {describe(e)}
            <div className="when">{fmt(e.createdAt)}</div>
            {e.kind === 'comment' && <div className="comment">{e.data.body}</div>}
          </li>
        ))}
      </ul>
      {evCursor && <button className="btn secondary" onClick={loadMoreEvents}>Load more activity</button>}

      {canWrite && (
        <form style={{ marginTop: 12 }} onSubmit={async (e) => {
          e.preventDefault();
          if (!comment.trim()) return;
          const text = comment;
          setComment('');
          await run(null, () => api(`/items/${id}/comments`, { method: 'POST', body: { body: text }, idemKey: uuid() }));
        }}>
          <div className="field"><label>Add comment</label><textarea className="f" rows={2} value={comment} onChange={(e) => setComment(e.target.value)} /></div>
          <button className="btn" disabled={busy || !comment.trim()}>Comment</button>
        </form>
      )}
    </aside>
  );
}
